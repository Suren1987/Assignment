############# - Question 31 - ##################
#------------------------------------------------------------------------------#

#### - 1. Clear environment - ####

rm(list = ls()); gc()

####- 2. Install/Load package - ####
# specify required pacakge
pkg <- c("sf", "stringr", "magrittr","readxl", "dplyr", "writexl")

check_package<- \(pkg){
pkgna <- names(which(sapply(sapply(pkg, find.package, quiet = TRUE), length) == 0))
if (length(pkgna) > 0) {
  message(
    "This function requires ", print(paste0(pkg, collapse = ", ")), " following packages.",
    "\nWould you like to install it now?\n1: yes\n2: no"
  )
  user <- readline(prompt = paste0("Selection: "))
  
  if (tolower(user) %in% c("1", "yes", "y")) {
    utils::install.packages(pkgna)
  } else {
    stop("Please install ggplot2 package or set show_grid = FALSE.")
  }
}
invisible(lapply(pkg, library, character.only = TRUE))
}

## install or load package
check_package(pkg = pkg)

####-3. Read Data - ####

prj_file_path  <- "./Project locations.xlsx"
question_sheet <- "Question 1"
question_range <- "A1:C11"
answer_sheet   <- "Your answers"
answer_range   <- "D2:F11"
prj_locs <- readxl::read_excel(path = prj_file_path, sheet = question_sheet,
                               range = question_range, col_names = TRUE)
# read kml files
kml_list <- list.files(path = "./", pattern = ".kml$",full.names = FALSE)
## print head/ all project

 head(prj_locs, 10)
 
# change the name to avoid space
 names(prj_locs)<- c("prj_id", "lat", "lon")
 
 # write a function such that it loops through each project reads data and write to location
 # given the small number of files, extent can be use to filter x and y data, 
 # however,if data set is huge, in such case automating the process is a key
 # Here in my example I am susing "sf" pacakge
 # assumed coordinate system is as per kml file
 # although coordinates are in lat/long format sf pacakge as of now consider 
 # them as planar coordinates; which may results slightly different results
 # compared to other packages/softwares
 #----------------------------------------------------------------------------#
 check_project_boundary <- \(prj_locs, kml_list){
  #prj_vec <- prj_locs[,"prj_id"]
   sf_use_s2(FALSE)
   edata <- list()
  for(prj in prj_locs$prj_id){ # prj_locs$prj_id[2]
     
    prj_ind <- which(prj_locs[,1] == prj)
    prj_num <- prj_locs[,1][prj_ind,]
    #prj_int <- as.character(prj_num)
    ## read associated project
    kml_prj <- kml_list[grep(paste0("^", prj_num, "_"), kml_list)]
    kml_sf <- sf::st_read(paste0("./", kml_prj))
    if(nrow(kml_sf)>1){
      kml_sf <- kml_sf|> dplyr::summarise()
    }else{
      kml_sf <- kml_sf
    }
    # read xy location for project 
    prj_xy <- prj_locs[prj_ind, c("lon", "lat")]|> st_as_sf(coords = c("lon", "lat"), crs = st_crs(kml_sf))
    
   # if(!st_intersects(prj_xy, kml_sf, sparse = FALSE)[1]==FALSE){
    if(is.na(as.integer(st_intersects(prj_xy, kml_sf), sparse = FALSE))){
      pol_cen <- st_centroid(kml_sf)
      pol_lon <- sf::st_coordinates(pol_cen)[,1]
      pol_lat <- sf::st_coordinates(pol_cen)[,2]
      ret_df<-  data.frame("inside" = "NO",
                 "lat" = pol_lat,
                 "lon" = pol_lon)
     ret_df
    } else{
      ret_df<- data.frame("inside" = "Yes",
                         "lat" = " ",
                         "lon" = "") 
    
    ret_df
    }
    
    edata[[prj_ind]] <- ret_df
  }
  
  ret_data <- do.call(rbind, edata)
   return(ret_data) 
   
 }

 ret<- check_project_boundary(prj_locs = prj_locs,kml_list = kml_list)
 
writexl::write_xlsx(x = ret,path ="./output_to_append.xlsx", col_names = TRUE,
                    format_headers = TRUE )

#  library(ggplot2)
# 
# ggplot()+geom_sf(data = kml_sf)+
#   geom_sf(data = prj_xy, size = 5)
